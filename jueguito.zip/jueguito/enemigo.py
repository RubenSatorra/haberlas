from random import randint as rng

class enemigo:

    atkcargado=False
    bloqueando=False
    culitoderana=False
    mododiablo=False
    ataques =["piedra", "papel", "tijera"]
    habilidades =["nada", "cargar", "bloquear","sanar"]
    def __init__(self, vida, ap):
        self.hp = vida
        self.ap = ap



from random import randint as rng

class enemigo:

    atkcargado=False
    bloqueando=False
    ataques =["piedra", "papel", "tijera"]
    habilidades =["nada", "cargar", "bloquear"]
    def __init__(self, vida, ap):
        self.hp = vida
        self.ap = ap



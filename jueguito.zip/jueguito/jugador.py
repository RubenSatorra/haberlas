class jugador:

    ataques =["piedra", "papel", "tijera"]
    atkcargado=False
    bloqueando=False
    culitoderana=False
    mododiablo=False

    def __init__(self, vida, ap):
        self.hp = vida
        self.ap = ap


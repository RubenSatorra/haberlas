from jugador import *
from enemigo import *
import random

def combate(jugador_instance, enemigo_instance, atkjugador, atkenemigo):
    max_ap = 10
    max_hp = 100
    if jugador_instance.hp>max_hp:
        jugador_instance.hp=100
    if enemigo_instance.hp>max_hp:
        enemigo_instance.hp=100


    if atkjugador == atkenemigo:
        print("-----------------------------------------------------")
        print("\nMismo movimiento, no ocurre nada, se ve un poco ridículo...")
        jugador_instance.atkcargado = False  # Reset after use
        enemigo_instance.atkcargado = False  # Reset after use
        if jugador_instance.ap<max_ap:
            jugador_instance.ap+=2
        elif enemigo_instance.ap<max_ap:
            enemigo_instance.ap+=2


    elif atkjugador == "piedra":
        if atkenemigo == "tijera":
            if not jugador_instance.mododiablo:
                enemigo_instance.hp -= 20
            else:
                enemigo_instance.hp-=60
                jugador_instance.mododiablo = False
            if jugador_instance.atkcargado:
                enemigo_instance.hp -= 20
                jugador_instance.atkcargado = False  # Reset after use

            print("-----------------------------------------------------")
            print("\nDAÑO!!")
            print("\nEl enemigo ha perdido el equilibrio!")
        elif atkenemigo == "papel":
            if not jugador_instance.mododiablo:
                jugador_instance.hp -= 20
            else:
                jugador_instance.hp-=60
                jugador_instance.mododiablo = False
            print("-----------------------------------------------------")
            print("\nFALLO!!")
            print("\n El enemigo te ha disparado!")
            if enemigo_instance.atkcargado:
                jugador_instance.hp -= 20
                enemigo_instance.atkcargado = False #Reset after use
                print("\nHA SIDO UN ATAQUE MUY FUERTE!")
            if jugador_instance.atkcargado:
                jugador_instance.atkcargado = False  # Reset after use


    elif atkjugador == "papel":
        if atkenemigo == "piedra":
            if not jugador_instance.mododiablo:
                enemigo_instance.hp -= 20
            else:
                enemigo_instance.hp-=60
                jugador_instance.mododiablo = False
            if jugador_instance.atkcargado:
                enemigo_instance.hp -= 20
                jugador_instance.atkcargado = False  # Reset after use
            print("-----------------------------------------------------")
            print("\nEl enemigo intenta tumbarte, pero logras disparar antes!")
            print("\nDAÑO!!")
        elif atkenemigo == "tijera":
            if not jugador_instance.mododiablo:
                jugador_instance.hp -= 20
            else:
                jugador_instance.hp-=60
                jugador_instance.mododiablo = False
            print("-----------------------------------------------------")
            print("\nEl enemigo te acuchilla antes de que puedas cargar el arco!")
            print("\nFALLO!!")
            if enemigo_instance.atkcargado:
                jugador_instance.hp -= 20
                enemigo_instance.atkcargado = False #Reset after use
                print("\n HA SIDO UN ATAQUE MUY FUERTE!")
            if jugador_instance.atkcargado:
                jugador_instance.atkcargado = False  # Reset after use


    elif atkjugador == "tijera":
        if atkenemigo == "papel":
            if not jugador_instance.mododiablo:
                enemigo_instance.hp -= 20
            else:
                enemigo_instance.hp-=60
                jugador_instance.mododiablo = False
            if jugador_instance.atkcargado:
                enemigo_instance.hp -= 20
                jugador_instance.atkcargado = False  # Reset after use
            print("-----------------------------------------------------")
            print("\nEl enemigo te dispara, pero eres más rápido y lo acuchillas!")
            print("\nDAÑO!!")
        elif atkenemigo == "piedra":
            if not jugador_instance.mododiablo:
                jugador_instance.hp -= 20
            else:
                jugador_instance.hp-=60
                jugador_instance.mododiablo = False
            print("-----------------------------------------------------")
            print("El enemigo te pega una patada y te tumba al suelo.")
            print("\nFALLO!!")
            if enemigo_instance.atkcargado:
                jugador_instance.hp -= 20
                enemigo_instance.atkcargado = False #Reset after use
                print("\n HA SIDO UN ATAQUE MUY FUERTE!")
            if jugador_instance.atkcargado:
                jugador_instance.atkcargado = False  # Reset after use
    
    # Add more elif/else blocks here to handle other attack combinations
    # ... "papel", "tijera" for the player vs. all enemy options.

    print(f"Tu vida actual es {jugador1.hp}")
    print(f"Tus puntos de acción actuales son {jugador1.ap}")
    print(f"\nLa vida actual del enemigo es {enemigo1.hp}\n")
    print("-----------------------------------------------------")


# Example usage:
jugador1 = jugador(100, 10)  # Create player instance
enemigo1 = enemigo(100, 10)  # Create enemy instance





opcion=0

while opcion != "0" and jugador1.hp > 0 and enemigo1.hp > 0:
    rnghabilidades= random.choice(enemigo.habilidades)
    if enemigo1.ap>=3 and random.choice(enemigo.habilidades) == "cargar":  #Use enemy AP
        enemigo1.atkcargado = True
        enemigo1.ap-=3
    elif enemigo1.ap>3 and random.choice(enemigo.habilidades) == "bloquear":
        enemigo1.bloqueando = True
        enemigo1.ap-=3
    elif enemigo1.ap>6 and random.choice(enemigo.habilidades) == "sanar":
        enemigo1.culitoderana = True
        enemigo1.ap-=9
        enemigo1.hp=+100
        print("El enemigo se ha curado?? (Menuda cerdada)")
        print("-----------------------------------------------------")
    if not jugador1.bloqueando:  # Enemy attacks ONLY if player is NOT blocking
        ataqenemigo = random.choice(enemigo.ataques)
        # No attack resolution yet; will be handled after player input
    elif jugador1.bloqueando: #Resolve the block here
        print("-----------------------------------------------------")
        print("¡¡¡Bloqueas el ataque del enemigo!!!")
        jugador1.bloqueando = False  # Reset block for next turn
        enemigo1.atkcargado=False #Even if the enemy charged, negate the attack
        enemigo1.bloqueando=False
        print(f"Tu vida actual es {jugador1.hp}")
        print(f"Tus puntos de acción actuales son {jugador1.ap}")
        print(f"\nLa vida actual del enemigo es {enemigo1.hp}\n")
        print("-----------------------------------------------------")
    if not jugador1.bloqueando:
        print("Escoge un ataque:")
        print("1. Patada")
        print("2. Arco")
        print("3. Espada")
    print("-----------------------------------------------------")
    if jugador1.atkcargado != True and jugador1.bloqueando != True:
        print("Habilidades:")
        print("4. Cargar ataque")
        print("5. Bloquear ataque")
        print("6. Ataque Salvaje") #triplica el daño que haces, pero también el que recibes
        print("7.Sana Sana") #recuperas mitad de la vida 1 vez por combate
        print("0. Salir")
    opcion = input("\n")
    if opcion == "5":  # Process blocking IMMEDIATELY
        if jugador1.ap >= 3:
            jugador1.bloqueando = True
            jugador1.ap -= 3
            print("-----------------------------------------------------")
            print("\nTe preparas para bloquear el siguiente ataque!\n")  # Immediate feedback
            print("-----------------------------------------------------")
        else:
            print("No tienes suficientes PA para bloquear.")
    elif not jugador1.bloqueando:
        match opcion:
            case "1":
                if not enemigo1.bloqueando:
                    if not jugador1.bloqueando and opcion in ("1","2","3"): #Only after player attack input if they didn't block. 
                        combate(jugador1, enemigo1, "piedra", ataqenemigo)
                else:
                    if enemigo1.bloqueando:
                        print("-----------------------------------------------------")
                        print("¡¡¡El enemigo bloquea tu ataque!!!")
                        jugador1.bloqueando = False  # Reset block for next turn
                        enemigo1.atkcargado=False #Even if the enemy charged, negate the attack
                        enemigo1.bloqueando=False
                        print(f"Tu vida actual es {jugador1.hp}")
                        print(f"Tus puntos de acción actuales son {jugador1.ap}")
                        print(f"\nLa vida actual del enemigo es {enemigo1.hp}\n")
                        print("-----------------------------------------------------")  
            case "2":
                if not enemigo1.bloqueando:
                    if not jugador1.bloqueando and opcion in ("1","2","3"): #Only after player attack input if they didn't block. 
                        combate(jugador1, enemigo1, "papel", ataqenemigo)
                else:
                    if enemigo1.bloqueando:
                        print("-----------------------------------------------------")
                        print("¡¡¡El enemigo bloquea tu ataque!!!")
                        jugador1.bloqueando = False  # Reset block for next turn
                        enemigo1.atkcargado=False #Even if the enemy charged, negate the attack
                        enemigo1.bloqueando=False
                        print(f"Tu vida actual es {jugador1.hp}")
                        print(f"Tus puntos de acción actuales son {jugador1.ap}")
                        print(f"\nLa vida actual del enemigo es {enemigo1.hp}\n")
                        print("-----------------------------------------------------") 
            case "3":
                if not enemigo1.bloqueando:
                    if not jugador1.bloqueando and opcion in ("1","2","3"): #Only after player attack input if they didn't block. 
                        combate(jugador1, enemigo1, "tijera", ataqenemigo)
                else:
                    if enemigo1.bloqueando:
                        print("-----------------------------------------------------")
                        print("¡¡¡El enemigo bloquea tu ataque!!!")
                        jugador1.bloqueando = False  # Reset block for next turn
                        enemigo1.atkcargado=False #Even if the enemy charged, negate the attack
                        enemigo1.bloqueando=False
                        print(f"Tu vida actual es {jugador1.hp}")
                        print(f"Tus puntos de acción actuales son {jugador1.ap}")
                        print(f"\nLa vida actual del enemigo es {enemigo1.hp}\n")
                        print("-----------------------------------------------------") 
            case "4":
                if jugador1.ap >= 3:  # Check AP
                    jugador1.atkcargado = True
                    jugador1.ap -= 3   # Deduct AP
                    print("Cargas tu ataque! Daño multiplicado!")
                else:
                    print("No tienes suficientes puntos de acción para cargar un ataque.")
            case "6":
                if jugador1.ap>=5:
                    jugador1.mododiablo = True
                    jugador1.ap-=5
                    print("Modo diablo")
                    obrigado=random.choice(jugador1.ataques)
                    combate(jugador1, enemigo1, obrigado, ataqenemigo)
                else:
                    print("Te faltan Puntos de Acción")
            case "7":
                if not jugador1.culitoderana:
                    jugador1.vida=100
                    jugador1.culitoderana=True
                    jugador1.ap=0
                    print("Te has curado!")
                elif jugador1.culitoderana:
                    print("Ya te has curado una vez en este combate")
                elif jugador1.ap<8:
                    print("Necesitas más puntos de acción para curarte")
            case "0":
                print("Cobarde")
            case _:
                print("\n Opcion incorrecta, escoge otra.")

print("Se acabó el combate!")
if jugador1.hp > enemigo1.hp:
    print("HAS GANADO!!!!!!")
else:
    print("HAS PERDIDO! VERGÜENZA PARA TU LINAJE!")

